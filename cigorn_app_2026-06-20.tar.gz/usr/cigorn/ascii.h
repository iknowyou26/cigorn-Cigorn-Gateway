/* 
 * File:   ascii.h
 * Author: john
 *
 * Created on August 17, 2010, 11:44 PM
 */

#ifndef _ASCII_H
#define	_ASCII_H

/*
 * just name the common ASCII control codes
 */
#define NUL	  0
#define SOH	  1
#define STX	  2
#define ETX	  3
#define EOT	  4
#define ENQ	  5
#define ACK	  6
#define BEL	  7
#define BS	  8
#define HT	  9
#define NL	 10
#define VT	 11
#define NP	 12
#define CR	 13
#define SO	 14
#define SI	 15
#define DLE	 16
#define DC1	 17
#define DC2	 18
#define DC3	 19
#define DC4	 20
#define NAK	 21
#define SYN	 22
#define ETB	 23
#define CAN	 24
#define EM	 25
#define SUB	 26
#define ESC	 27
#define FS	 28
#define GS	 29
#define RS	 30
#define US	 31
#define SP	 32
#define DEL	127

#endif	/* _ASCII_H */

